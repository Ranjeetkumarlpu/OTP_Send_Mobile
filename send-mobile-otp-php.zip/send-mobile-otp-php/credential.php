<?php 
	/*Enter your API_KEY*/
	define("API_KEY", '2f6e8d-842219-cbc2cf-71c94a-d958f1');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>