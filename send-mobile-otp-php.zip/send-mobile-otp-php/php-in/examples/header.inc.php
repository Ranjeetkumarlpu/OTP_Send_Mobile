<?php
require_once('../textlocal.class.php');
$textLocal = new Textlocal('demo@txtlocal.com', 'apidemo123');
?>